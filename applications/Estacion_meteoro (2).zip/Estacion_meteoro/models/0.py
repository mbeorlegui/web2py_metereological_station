from gluon.storage import Storage
settings = Storage()

settings.migrate = True
settings.title = 'Estacion Meteorologica'
settings.subtitle = 'powered by web2py-g8'
settings.author = 'you'
settings.author_email = 'you@example.com'
settings.keywords = ''
settings.description = ''
settings.layout_theme = 'Default'
settings.database_uri = 'sqlite://storage.sqlite'
settings.security_key = '9d7bc445-2fc4-493e-b2ee-db36be6ee8b8'
settings.email_server = 'localhost'
settings.email_sender = 'you@example.com'
settings.email_login = ''
settings.login_method = 'local'
settings.login_config = ''
settings.plugins = []
